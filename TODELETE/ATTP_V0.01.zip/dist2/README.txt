Running our ATTP GUI

To run our Algorithmic Trading Testing Platform - WOLF:
1. Open the downloaded zip from our website and extract it to the desired directory.
2. Double click on WOLF.jar.
3. Pick a strategy.
4. Choose the data source.
5. Enter the N, TH, Start and End Value.
6. Click the "Run" button.
7. Wait for the excel file to be generated.
8. Follow the link to the excel file.
